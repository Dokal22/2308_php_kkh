	<header>	
		<div class="container">
			<div class="header_div">
				<img src="/project1/img/cart.png" alt="">
			</div>
			<h1 class="header_h1">장</h1>
			<h1 class="header_h2">보자</h1>
		</div>
	</header>