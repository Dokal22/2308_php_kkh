<nav class="navbar navbar-expand-lg navbar-light bg-light <?php if(!isset($imList)){echo "position-absolute w-100";} ?>">
  <div class="container-fluid">
    <a class="navbar-brand" href="/midium_board/src/list.php">Midium_board</a>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
    </div>
  </div>
</nav>